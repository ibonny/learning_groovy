package personal.bonnycasi.webdemo

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class WebdemoApplication {

	static void main(String[] args) {
		SpringApplication.run(WebdemoApplication, args)
	}

}
